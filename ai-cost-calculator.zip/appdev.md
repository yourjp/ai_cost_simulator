# AI Pricing App Development Script

이 문서는 현재 AI 가격 시뮬레이터 앱 수준까지 개발/수정할 때 사용하는 작업 스크립트다.
새 작업자는 이 문서와 `DATA_SPEC.md`를 함께 읽고, 데이터 갱신부터 UI 검증과 배포 준비까지 같은 기준으로 진행한다.

## 1. 목표

- OpenAI, Anthropic, Google의 API 모델 가격을 비교하는 Next.js 대시보드를 유지한다.
- 문서작성/코딩 용도에 맞는 고성능 모델과 가성비 모델을 함께 비교한다.
- 데이터는 Markdown(`data.md`)으로 관리하고, 앱은 파싱된 JSON(`dynamicData.json`)을 사용한다.
- 사용자가 데이터 파일을 직접 업로드해도 대시보드가 즉시 갱신되도록 유지한다.
- GitHub Pages와 Vercel 양쪽 배포를 고려해 정적 export 빌드가 깨지지 않게 한다.

## 2. 핵심 파일

- `DATA_SPEC.md`: 데이터 작성 규격. 새 데이터 생성 또는 수정 시 가장 먼저 읽는다.
- `data.md`: 앱이 읽는 최신 데이터 원본.
- `data-YY-MM-DD.md`: 날짜별 반영본. 예: `data-26-07-31.md`.
- `scripts/parse-data.js`: `data.md`를 읽어 `dynamicData.json`을 생성한다.
- `src/components/calculator/dynamicData.json`: 앱에서 import하는 구조화 데이터.
- `src/components/calculator/CalculatorDashboard.tsx`: 메인 대시보드 UI.
- `src/components/calculator/PricingDataAgent.ts`: 기본 가격 데이터 fallback.
- `src/components/calculator/SimulationEngineAgent.ts`: 비용 계산 로직.
- `src/components/calculator/UIStateAgent.ts`: 비율 조정 등 UI 상태 보조 로직.
- `next.config.ts`: static export, GitHub Pages basePath, Vercel 배포 조건을 관리한다.

## 3. 데이터 작성 규칙

1. 새 데이터셋을 만들거나 최신화할 때는 `DATA_SPEC.md`를 우선한다.
2. 반영본은 `data-YY-MM-DD.md` 형식으로 저장하고, 같은 내용을 `data.md`에도 반영한다.
3. `data.md`와 날짜별 반영본은 내용이 같아야 한다.
4. 데이터에는 반드시 다음 4개 표를 포함한다.
   - 모델 요금 테이블
   - 모델 성능 스펙 테이블
   - 뉴스 타임라인 테이블
   - 최근 6개월 가격 추이 테이블
5. 가격은 숫자만 넣는다. 예: `2.00`, `12.00`.
6. 모델명은 가격 테이블과 스펙 테이블에서 정확히 같아야 한다.
7. Vals Index 값이 없으면 모델을 제거하지 말고 `없음`으로 표시한다.
8. 수치 없는 컨텍스트/출력 한도는 `-`로 표시한다.
9. 뉴스와 가격 추이에는 최근 6개월간의 출시, 가격 변경, 모델 교체, deprecated/retired 정보를 포함한다.
10. Google Pro 계열은 최신 Pro 모델이 없더라도 직전 일반 제공 Pro 모델이 확인되면 high 모델 비교 후보에 유지한다.
11. 최신 버전이 없을 때도 같은 역할의 이전 일반 제공 모델이 있으면 표시한다.
12. deprecated, retired, legacy, removed 모델은 비교 목적이 아니면 제거하고, 이력은 뉴스 타임라인에 남긴다.

## 4. 모델 구성 기준

- 제공사는 `OpenAI`, `Anthropic`, `Google`만 사용한다.
- 각 회사별 최소 2개 모델을 유지한다.
- 가능하면 회사별로 high 1~2개, mid 2개 정도를 포함한다.
- high는 flagship, 고난도 추론, 코딩, 장문 작업용 모델이다.
- mid는 비용 효율, 빠른 응답, 대량 처리, 일반 업무용 모델이다.
- Google은 `Pro`, `Flash`, `Flash-Lite`의 역할이 다르므로 숫자 버전만 보고 등급을 정하지 않는다.
- 문서작성/코딩 비교에서는 Pro 계열, 고성능 Claude/OpenAI 모델, 효율형 Flash/Sonnet/Luna 계열을 함께 보여준다.

## 5. 성능 지표

- 성능 비교 지표는 `Vals Index`를 사용한다.
- 앱은 `Vals Index`를 숫자로 파싱해 높은 순으로 정렬한다.
- `없음`은 정렬 시 0으로 취급하되, 표에는 `없음` 그대로 표시한다.
- Vals Index가 없어도 모델은 유지한다. 빠지면 비교 대상 자체가 사라지므로 의미가 줄어든다.

## 6. UI 동작 요구사항

- 개별 모델 상세 요금 일람은 회사별 high 1개, mid 1개 슬롯을 보여준다.
- 같은 회사와 등급에 모델이 여러 개 있으면 선택박스로 모델을 고르게 한다.
- 가성비 모델(mid)도 회사별 후보가 2개 정도 있으면 선택박스로 선택 가능해야 한다.
- 선택된 모델만 비용 시뮬레이션과 상세 요금 카드에 반영한다.
- 성능 비교 표는 high와 mid를 분리해 표시한다.
- 성능 비교 표에는 회사, 모델명, 컨텍스트, 출력 한도, Vals Index, 입력/출력 요금을 표시한다.
- 신규모델출시, 단가 변동 추세 영역은 공급사별 최근 6개월 신규 모델 출시와 가격 변경 정보를 모두 표시한다.
- 가격 추이 차트는 high/mid를 분리하고 최근 6개월 기준일을 15일 단위로 사용한다.
- UI 텍스트는 한국어가 깨지지 않도록 UTF-8 저장 상태를 확인한다.

## 7. 화면 구조 재현 규칙

현재 앱 화면 구조를 재생성하거나 리팩터링할 때는 아래 순서와 배치를 유지한다.

### 7.1 전체 레이아웃

- 전체 페이지는 어두운 배경의 단일 대시보드 화면으로 구성한다.
- 페이지 최상위 컨테이너는 최소 화면 높이를 채우고, 데스크톱에서는 넓은 여백을 둔다.
- 콘텐츠 폭은 `max-w-7xl` 수준으로 제한하고 가운데 정렬한다.
- 주요 섹션은 위에서 아래로 다음 순서를 따른다.
  1. 헤더
  2. 메인 시뮬레이션 영역
  3. 공급자 혼합 비용 비교 영역
  4. 개별 모델 상세 요금 일람
  5. high/mid 성능 비교 표
  6. high/mid 최근 6개월 가격 추이 차트
  7. 공급사별 신규모델출시, 단가 변동 추세 영역
  8. 푸터

### 7.2 헤더

- 왼쪽에는 앱 제목과 짧은 설명을 둔다.
- 오른쪽에는 데이터 업데이트 날짜, 앱 업데이트 날짜, Markdown 업로드 버튼을 둔다.
- Markdown 업로드는 `.md` 파일을 받아 `parseMarkdownData`로 가격/성능/뉴스/추이 데이터를 갱신한다.

### 7.3 메인 시뮬레이션 영역

- 데스크톱에서는 12컬럼 그리드를 사용한다.
- 왼쪽 입력 패널은 5컬럼, 오른쪽 결과 패널은 7컬럼을 차지한다.
- 모바일에서는 1컬럼으로 세로 배치한다.

왼쪽 입력 패널에는 다음 카드가 포함되어야 한다.

- 기본 파라미터: 총 사용자 수, 환율, 통화 모드 등 핵심 입력값.
- 사용자 유형 비율: 일반/헤비/개발자/헤비 개발자 비중과 인원 조정.
- 사용자별 토큰 사용량: 입력/출력 토큰을 k 단위로 조정.
- 모델 믹스 비율: 공급사별 high/mid 사용 비율 조정과 전체 동기화 옵션.

오른쪽 결과 패널에는 다음 카드가 포함되어야 한다.

- 공급자별 예상 월간 비용 요약 카드 3개.
- 최저 비용 공급자, 최고 비용 공급자, 최대 비용 차이 요약.
- 예상 월간 비용 시각화 막대 차트.
- 사용자 유형별 비용 또는 토큰 사용량 요약.

### 7.4 공급자 혼합 비용 비교

- 메인 시뮬레이션 영역 아래에 별도 전체 폭 섹션으로 둔다.
- OpenAI, Anthropic, Google 순서로 표시한다.
- 각 공급자의 high/mid 혼합 비율과 예상 비용을 비교한다.
- 회사 색상은 OpenAI 녹색, Anthropic 주황/호박색, Google 파란색 계열을 유지한다.

### 7.5 개별 모델 상세 요금 일람

- 전체 폭 테이블 섹션으로 둔다.
- 공급사 정렬은 Google, OpenAI, Anthropic 순서를 기본으로 유지한다.
- 같은 공급사/등급에 후보가 여러 개 있으면 모델명 칸 또는 인접 위치에 선택박스를 제공한다.
- 선택박스는 `provider:tier` 단위 상태로 관리한다.
- 선택된 모델만 비용 계산과 요금 일람에 반영한다.
- 선택된 모델은 high/mid 가격 추이 차트의 legend와 최신 기준일 가격에도 함께 반영한다.
- 표에는 제공사, 등급, 모델명, 입력 요금, 출력 요금, 혼합 비율, 예상 비용을 보여준다.

### 7.6 성능 비교 표

- 개별 모델 상세 요금 일람 아래에 2컬럼 섹션으로 둔다.
- 왼쪽은 high-tier 성능 비교, 오른쪽은 mid-tier 성능 비교다.
- 모바일에서는 두 표가 세로로 쌓인다.
- 각 표는 Vals Index 높은 순으로 정렬한다.
- Vals Index가 `없음`인 모델은 점수 0으로 정렬하되 행은 제거하지 않는다.
- 표 아래에는 모델별 핵심 특장점 요약을 짧게 반복 표시한다.
- 성능 비교 설명 박스에는 Vals Index의 의미를 설명한다.

### 7.7 가격 추이 차트

- 성능 비교 표 아래에 2컬럼 섹션으로 둔다.
- 왼쪽은 high-tier 최근 6개월 가격 추이, 오른쪽은 mid-tier 최근 6개월 가격 추이다.
- X축은 `data.md`의 15일 단위 기준일을 `MM/DD` 형식으로 표시한다.
- Y축은 USD / 1M input tokens 기준으로 표시한다.
- Y축 최대값은 해당 차트에 표시되는 모델 입력 요금 최고값의 110%로 자동 설정한다.
- OpenAI, Anthropic, Google 3개 선을 모두 표시한다.
- 차트 legend에는 선택된 대표 모델명과 최신 입력 요금을 표시한다.
- 차트 선과 legend 순서는 최신 기준일의 입력 요금이 낮은 모델부터 높은 모델 순으로 자동 배열한다.
- high와 mid 차트 모두 같은 가격순 정렬 규칙을 적용한다.
- 개별 모델 상세 요금 일람에서 선택박스로 모델을 바꾸면 같은 공급사/등급의 가격 추이 차트 최신 기준점도 선택 모델의 현재 입력 요금으로 갱신한다.

### 7.8 신규모델출시, 단가 변동 추세 영역

- 가격 추이 차트 아래에 전체 폭 섹션으로 둔다.
- 내부는 3컬럼으로 OpenAI, Anthropic, Google을 나란히 표시한다.
- 모바일에서는 1컬럼으로 세로 배치한다.
- 각 공급사 카드에는 최근 6개월 신규 모델 출시, 일반 제공 전환, 가격 인하/인상 정보를 최신순으로 모두 표시한다.
- 최신 항목에는 `(최근)` 표시를 붙인다.

### 7.9 시각 스타일

- 기본 배경은 짙은 slate/indigo 계열을 사용한다.
- 카드는 반투명 어두운 배경, 얇은 slate border, 은은한 shadow를 사용한다.
- 섹션 카드의 radius는 기존처럼 `rounded-xl` 또는 `rounded-2xl` 수준을 유지한다.
- 주요 아이콘은 `lucide-react`를 사용한다.
- 차트는 `recharts`를 사용한다.
- 표는 작은 글꼴과 `overflow-x-auto`를 사용해 모바일에서도 깨지지 않게 한다.
- 중첩 카드가 과도하게 보이지 않도록, 큰 섹션 안의 반복 항목만 카드처럼 처리한다.

## 8. 파싱 구조

`scripts/parse-data.js`는 `data.md`에서 다음 구조를 읽는다.

- metadata: 데이터 업데이트 날짜
- pricingData: 모델명, 제공사, 등급, 입력 요금, 출력 요금
- performanceData: 컨텍스트, 출력 한도, Vals Index, 특장점
- newsData: 제공사별 날짜, 헤드라인, 세부 내용
- trendData: high/mid별 최근 6개월 입력 요금 추이

데이터 수정 후 반드시 실행한다.

```powershell
node scripts/parse-data.js
```

정상 기준:

- Parsed Models 수와 Specs 수가 같아야 한다.
- News는 최근 6개월 주요 변경 사항을 포함해야 한다.
- Trends는 high와 mid 각각 최근 6개월의 15일 단위 기준일을 포함해야 한다.

## 9. 데이터 간 로직

`data.md`의 4개 표는 서로 독립된 표가 아니라 같은 모델 데이터셋을 다른 화면에 공급하는 연결 구조다.
한 표만 고치면 앱 화면 일부가 어긋나므로 아래 관계를 반드시 유지한다.

### 9.1 가격 테이블과 스펙 테이블

- 가격 테이블의 모든 모델은 스펙 테이블에 반드시 같은 모델명으로 존재해야 한다.
- 스펙 테이블의 모든 모델도 가격 테이블에 반드시 같은 모델명으로 존재해야 한다.
- `Parsed Models` 수와 `Specs` 수가 다르면 데이터 반영은 실패로 본다.
- 가격 테이블의 `제공사`와 `등급`이 앱의 필터링 기준이다.
- 스펙 테이블의 `Vals Index`, `컨텍스트`, `출력 한도`, `핵심 특장점`은 성능 비교 표에 붙는다.
- Vals Index가 `없음`이어도 가격 테이블과 스펙 테이블 양쪽에 모델을 남긴다.

### 9.2 모델 선택박스와 비용 계산

- 앱은 `제공사 + 등급` 조합을 하나의 선택 슬롯으로 본다.
- 슬롯 키는 개념적으로 `OpenAI:high`, `OpenAI:mid`, `Anthropic:high`, `Anthropic:mid`, `Google:high`, `Google:mid`다.
- 같은 슬롯에 모델이 2개 이상 있으면 선택박스를 표시한다.
- 선택된 모델만 `filteredPricingData`에 들어간다.
- 비용 계산 엔진은 전체 가격 테이블이 아니라 `filteredPricingData`를 기준으로 계산한다.
- 따라서 후보 모델을 추가해도 사용자가 선택하지 않은 모델은 상세 비용 결과에 직접 반영되지 않는다.
- 가격 추이 차트도 `filteredPricingData`를 참조해 최신 기준일 값을 선택 모델 가격으로 보정한다.
- 성능 비교 표는 선택된 모델만이 아니라 등급별 전체 결과 후보를 보여주는 방식인지, 선택 모델만 보여주는 방식인지 구현 의도를 명확히 유지한다. 현재 기준은 계산 결과와 연결된 모델 목록을 등급별로 표시한다.

### 9.3 가격 테이블과 가격 추이 테이블

- 가격 추이 테이블은 각 등급별 대표 입력 요금 흐름을 보여준다.
- 최신 기준일 행은 가격 테이블의 현재 대표 모델 입력 요금과 일치해야 한다.
- high 추이의 최신 Google 값은 Google high 대표 모델의 입력 요금과 맞춘다.
- mid 추이의 최신 Google 값은 Google mid 대표 모델의 입력 요금과 맞춘다.
- 대표 모델을 바꾸면 가격 추이 차트 legend와 최신 기준일 값도 함께 확인한다.
- 과거 가격을 찾지 못해 최신 가격을 반복 입력한 경우, 뉴스 타임라인 또는 작업 요약에 `과거 가격 변경 확인 불가`를 남긴다.

### 9.4 뉴스 타임라인과 모델 목록

- 가격 테이블에 새 모델을 추가하면 뉴스 타임라인에 출시 또는 일반 제공 전환 이력을 추가한다.
- 가격이 바뀐 모델은 뉴스 타임라인에 변경일과 변경 후 요금을 남긴다.
- 모델이 deprecated/retired/removed 되면 가격/스펙 표에서 제거하고 뉴스 타임라인에 제거 또는 대체 모델 이력을 남긴다.
- 최신 모델이 없어서 이전 일반 제공 모델을 유지하는 경우, 뉴스 타임라인 또는 특장점에 이전 세대 유지 사유를 남긴다.
- Google Pro 계열처럼 역할상 중요한 모델은 최신 버전 부재와 이전 버전 유지 여부를 뉴스/특장점 중 한 곳에 드러낸다.

### 9.5 스펙 값과 정렬 로직

- Vals Index는 숫자와 `%`만 있으면 숫자로 파싱된다.
- `없음`, `-`, 빈 값은 정렬 점수 0으로 처리한다.
- 정렬 점수가 0이어도 모델 행은 제거하지 않는다.
- 컨텍스트와 출력 한도는 표시용 값이므로 `-`가 있어도 파싱 실패로 보지 않는다.
- 성능 비교에서 수치가 없는 모델은 점수 경쟁에서는 뒤로 가지만, 사용 가능한 비교 후보로 남아야 한다.

### 9.6 뉴스와 가격 추이의 시간 범위

- 뉴스 타임라인은 최근 6개월의 주요 출시, 가격 변경, 모델 교체 이력을 최신순으로 표시한다.
- 가격 추이 테이블은 최근 6개월 범위를 15일 단위로 오래된 순서에서 최신 순서로 작성한다.
- 뉴스는 내림차순, 가격 추이는 오름차순이라는 정렬 방향 차이를 유지한다.
- 기준일은 모두 `YYYY-MM-DD` 형식을 사용한다.
- `data.md` 상단의 업데이트 날짜와 `data-YY-MM-DD.md` 파일명 날짜는 같은 날짜를 가리켜야 한다.

### 9.7 공급사 균형 로직

- 공급사별 최소 2개 모델을 유지한다.
- 공급사별 high와 mid가 모두 있으면 시뮬레이션과 선택 UI가 가장 안정적이다.
- 어느 공급사에 high 또는 mid가 없으면 해당 슬롯의 선택박스와 계산 결과가 비게 되므로, 공식 일반 제공 모델 중 이전 버전이라도 확인해 채운다.
- 단, retired/deprecated 모델로 빈 슬롯을 채우지는 않는다.
- 모델 수가 너무 많아지면 역할별 대표 후보를 우선한다. 기준은 high 1~2개, mid 2개 정도다.

### 9.8 데이터 변경 후 필수 검증

데이터 표를 하나라도 바꾸면 아래 순서로 확인한다.

```powershell
node scripts/parse-data.js
npm run lint
npm run build
```

확인 포인트:

- Parsed Models와 Specs 수가 같다.
- `dynamicData.json`의 `pricingData`와 `performanceData`에 같은 모델명이 있다.
- `newsData`에 OpenAI, Anthropic, Google 키가 모두 있다.
- `trendData.high`와 `trendData.mid`가 모두 있다.
- 최신 추이값과 현재 대표 가격이 어긋나지 않는다.

## 10. 기본값

앱을 처음 열었을 때의 기본 상태는 아래 값을 따른다.
기본값을 바꾸면 UI 표시, 계산 결과, 푸터 설명, 테스트 기대값을 함께 확인한다.

### 10.1 기본 시뮬레이션 값

| 항목 | 기본값 | 설명 |
| :--- | :--- | :--- |
| 총 사용자 수 | 1000 | 월간 비용을 계산할 전체 사용자 수 |
| 환율 | 1500 | USD 비용을 KRW로 변환할 때 쓰는 원/달러 값 |
| 통화 표시 | USD | 기본 차트와 비용 표시는 달러 기준 |
| 차트 모드 | blended | 기본 차트는 공급사별 high/mid 혼합 요금 기준 |
| 데이터 업데이트 표시 | `dynamicData.metadata.dataUpdatedAt` 또는 `확인 필요` | `data.md`에서 파싱한 날짜를 우선 사용 |
| 모델 선택 상태 | 비어 있음 | 각 `제공사 + 등급` 슬롯의 첫 번째 모델을 자동 선택 |

### 10.2 사용자군 기본 비율

| 사용자군 | 기본 비율 | 기본 인원(총 1000명 기준) | 월 입력 토큰 | 월 출력 토큰 |
| :--- | :--- | :--- | :--- | :--- |
| light | 60% | 600명 | 300,000 | 75,000 |
| heavy | 20% | 200명 | 1,500,000 | 400,000 |
| stdDev | 15% | 150명 | 5,000,000 | 1,000,000 |
| heavyDev | 5% | 50명 | 20,000,000 | 4,000,000 |

- 개발자 전체 비율은 기본 20%다.
- 개발자 그룹은 `stdDev 15% + heavyDev 5%`로 시작한다.
- 비개발자 그룹은 `light 60% + heavy 20%`로 시작한다.
- 개발자 비율을 바꾸면 기존 개발자 내부 비율과 비개발자 내부 비율을 유지한 채 재분배한다.
- 각 사용자군 비율은 총합 100%를 유지해야 한다.

### 10.3 토큰 입력 UI 기본 표시값

토큰 입력 필드는 실제 계산값을 1,000으로 나눈 k 단위 문자열로 보여준다.

| 필드 | 표시 기본값 | 실제 계산값 |
| :--- | :--- | :--- |
| light input | 300 | 300,000 |
| light output | 75 | 75,000 |
| heavy input | 1,500 | 1,500,000 |
| heavy output | 400 | 400,000 |
| stdDev input | 5,000 | 5,000,000 |
| stdDev output | 1,000 | 1,000,000 |
| heavyDev input | 20,000 | 20,000,000 |
| heavyDev output | 4,000 | 4,000,000 |

### 10.4 모델 믹스 기본값

| 공급사 | high 기본 비율 | mid 기본 비율 |
| :--- | :--- | :--- |
| OpenAI | 20% | 80% |
| Anthropic | 20% | 80% |
| Google | 20% | 80% |

- 모델 믹스 조정은 기본적으로 `함께 움직이기`가 켜져 있다.
- `함께 움직이기` 상태에서 한 공급사의 high/mid 비율을 바꾸면 3개 공급사 모두 같은 비율로 동기화한다.
- `따로 움직이기` 상태에서는 선택한 공급사의 비율만 바꾼다.
- 한 공급사 안에서 high와 mid 비율 합은 항상 100%다.

### 10.5 기본 모델 선택 규칙

- `selectedModelBySlot`은 초기값이 빈 객체다.
- 앱은 각 공급사/등급 슬롯에서 데이터 순서상 첫 번째 모델을 기본 선택 모델로 사용한다.
- 따라서 `data.md`의 가격 테이블 정렬은 기본 선택에 영향을 준다.
- 기본 선택으로 삼고 싶은 모델은 같은 공급사/등급 후보 중 위쪽에 둔다.
- 예를 들어 Google high에서 `gemini-3.6-flash`가 `gemini-3.1-pro`보다 위에 있으면, 첫 로딩 시 Google high 대표는 `gemini-3.6-flash`다.

### 10.6 계산 기본식

사용자군별 총 토큰:

```text
userCountByType = totalUsers * userRatio / 100
totalInputTokens = sum(userCountByType * monthlyInputTokensByType)
totalOutputTokens = sum(userCountByType * monthlyOutputTokensByType)
```

모델별 월 비용:

```text
usdCost = (totalInputTokens / 1,000,000 * inputCostPer1M)
        + (totalOutputTokens / 1,000,000 * outputCostPer1M)
krwCost = usdCost * exchangeRate
```

공급사별 혼합 월 비용:

```text
providerUsdCost = highModelUsdCost * (highRatio / 100)
                + midModelUsdCost * (midRatio / 100)
```

- USD 비용은 소수점 둘째 자리 기준으로 반올림한다.
- KRW 비용은 정수로 반올림한다.
- 공급사에 high 또는 mid 모델이 없으면 해당 등급 비용은 0으로 계산되므로 데이터에서 빈 슬롯을 만들지 않는다.

### 10.7 fallback 기본값

- `PricingDataAgent`의 fallback은 `dynamicData.pricingData`를 우선 사용한다.
- `dynamicData.pricingData`를 사용할 수 없을 때만 코드 내부 fallback 목록을 사용한다.
- 코드 내부 fallback은 오래될 수 있으므로, 실제 기준 데이터는 항상 `data.md`와 `dynamicData.json`이다.
- fallback 목록을 수정할 때도 `data.md`의 최신 모델 구성과 크게 어긋나지 않게 맞춘다.

## 11. 개발 절차

1. `DATA_SPEC.md`를 읽고 데이터 규격을 확인한다.
2. 공식 가격표와 모델 문서를 확인해 모델 목록과 가격을 정리한다.
3. `data-YY-MM-DD.md`를 만들거나 수정한다.
4. 같은 내용을 `data.md`에 반영한다.
5. 데이터 간 로직에 따라 가격/스펙/뉴스/추이 표의 연결 관계를 확인한다.
6. 기본값을 바꾸는 변경이면 `기본값` 섹션과 실제 코드가 일치하는지 확인한다.
7. `node scripts/parse-data.js`를 실행해 `dynamicData.json`을 갱신한다.
8. UI가 새 데이터 구조를 제대로 쓰는지 `CalculatorDashboard.tsx`를 확인한다.
9. lint와 build를 실행한다.
10. 변경 내용을 확인하고 필요하면 ZIP 또는 GitHub/Vercel 배포를 진행한다.

검증 명령:

```powershell
node scripts/parse-data.js
npm run lint
npm run build
```

## 12. 배포 기준

- 사용자가 `반영` 또는 `배포`라고 명시했을 때만 ZIP 패키징이나 remote push를 실행한다.
- GitHub 반영 시:

```powershell
git status --short --branch
git add DATA_SPEC.md data.md data-YY-MM-DD.md scripts/parse-data.js src/components/calculator/dynamicData.json src/components/calculator/CalculatorDashboard.tsx
git commit -m "Update AI pricing data and dashboard"
git push origin main
```

- Vercel 자동 배포를 병행하려면 GitHub repo를 Vercel 프로젝트로 import한다.
- GitHub Pages와 Vercel을 함께 쓸 때는 `next.config.ts`의 `basePath`가 GitHub Pages에서만 켜지도록 환경변수를 분리한다.

권장 설정:

```ts
import type { NextConfig } from "next";

const isGithubPages = process.env.DEPLOY_TARGET === "github-pages";

const nextConfig: NextConfig = {
  output: "export",
  basePath: isGithubPages ? "/ai_cost_simulator" : "",
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
```

GitHub Actions에는 다음 환경변수를 둔다.

```yaml
env:
  DEPLOY_TARGET: github-pages
```

Vercel은 기본적으로 `DEPLOY_TARGET` 없이 빌드하므로 루트 경로로 배포된다.

## 13. 완료 체크리스트

- [ ] `DATA_SPEC.md`의 최신 규칙을 반영했다.
- [ ] `data-YY-MM-DD.md`와 `data.md`의 내용이 같다.
- [ ] 가격 테이블과 스펙 테이블의 모델명이 정확히 일치한다.
- [ ] Parsed Models와 Specs 수가 같다.
- [ ] Vals Index가 없는 모델도 `없음`으로 유지했다.
- [ ] 최신 모델이 없을 때 이전 일반 제공 모델을 유지했다.
- [ ] Google Pro 계열 누락 여부를 확인했다.
- [ ] 회사별 high/mid 후보가 선택박스에 표시될 만큼 유지됐다.
- [ ] 각 `제공사 + 등급` 선택 슬롯에 적절한 후보가 있다.
- [ ] 가격 추이 최신 기준일 값이 현재 대표 모델 입력 요금과 일치한다.
- [ ] 새 모델, 가격 변경, 제거 모델의 이력이 뉴스 타임라인에 반영됐다.
- [ ] 기본 사용자 수, 환율, 통화 모드, 차트 모드가 문서의 기본값과 일치한다.
- [ ] 사용자군 비율과 토큰 기본값이 문서의 기본값과 일치한다.
- [ ] 모델 믹스 기본값이 high 20%, mid 80%로 유지된다.
- [ ] 기본 선택 모델 순서가 `data.md` 가격 테이블 순서와 의도대로 맞다.
- [ ] 화면 섹션 순서가 헤더, 메인 시뮬레이션, 혼합 비용 비교, 상세 요금 일람, 성능 비교, 가격 추이, 신규모델출시/단가 변동 추세, 푸터 순서로 유지됐다.
- [ ] 데스크톱 12컬럼 메인 레이아웃과 모바일 1컬럼 배치가 유지됐다.
- [ ] high/mid 성능 비교와 가격 추이 차트가 각각 2컬럼으로 표시된다.
- [ ] high/mid 가격 추이 차트의 모델 legend와 선 순서가 최신 입력 요금 기준 저가에서 고가 순으로 자동 정렬된다.
- [ ] 개별 모델 상세 요금 일람에서 모델을 변경하면 high/mid 가격 추이 차트의 모델명과 최신 기준일 가격이 함께 변경된다.
- [ ] high/mid 가격 추이 차트의 Y축 최대값이 표시 모델 최고 입력 요금의 110%로 설정된다.
- [ ] 최근 6개월 뉴스와 15일 단위 가격 추이를 포함했다.
- [ ] `node scripts/parse-data.js`가 성공했다.
- [ ] `npm run lint`가 성공했다.
- [ ] `npm run build`가 성공했다.
- [ ] 배포가 필요하면 사용자의 `반영` 또는 `배포` 지시 후 push/패키징했다.

## 14. 작업 지시 프롬프트

다음 프롬프트를 새 작업자나 AI에게 그대로 전달하면 현재 수준의 앱 개발/수정 기준을 맞출 수 있다.

```text
D:\AI_Pricing 프로젝트에서 AI 가격 시뮬레이터 앱을 현재 수준으로 유지/개발해줘.

반드시 appdev.md와 DATA_SPEC.md를 먼저 읽고 따른다.

요구사항:
1. data.md는 DATA_SPEC.md의 4개 표 구조를 유지한다.
2. 새 데이터 반영본은 data-YY-MM-DD.md 형식으로 만들고 같은 내용을 data.md에도 반영한다.
3. OpenAI, Anthropic, Google 모델을 회사별 최소 2개 이상 넣는다.
4. 가능하면 high 1~2개, mid 2개 정도를 포함한다.
5. Google은 Pro, Flash, Flash-Lite 역할을 구분한다.
6. 최신 Pro가 없으면 이전 일반 제공 Pro라도 high 후보로 표시한다.
7. Vals Index를 성능 지표로 사용하고, 값이 없으면 모델을 지우지 말고 없음으로 표시한다.
8. 개별 모델 상세 요금 일람은 회사별 high/mid 슬롯을 보여주고 후보가 여러 개면 선택박스를 제공한다.
9. 가성비 모델도 후보가 여러 개면 선택박스로 선택할 수 있게 한다.
10. 신규모델출시, 단가 변동 추세와 가격 추이는 최근 6개월 정보를 포함하고, 가격 추이는 15일 단위로 표시한다.
11. 화면 구조는 appdev.md의 화면 구조 재현 규칙을 따른다.
12. 섹션 순서는 헤더, 메인 시뮬레이션, 혼합 비용 비교, 상세 요금 일람, 성능 비교, 가격 추이, 신규모델출시/단가 변동 추세, 푸터 순서로 유지한다.
13. 데스크톱은 메인 영역 12컬럼, 좌측 입력 5컬럼, 우측 결과 7컬럼 구조를 유지하고 모바일은 1컬럼으로 쌓는다.
14. 가격 테이블, 스펙 테이블, 뉴스 타임라인, 가격 추이 테이블 간 연결 관계를 appdev.md의 데이터 간 로직대로 유지한다.
15. 가격 테이블과 스펙 테이블의 모델명은 1:1로 일치시키고 Parsed Models와 Specs 수를 같게 한다.
16. 가격 추이 최신 기준일 값은 현재 대표 모델 입력 요금과 일치시킨다.
17. 기본값은 appdev.md의 기본값 섹션을 따른다. 총 사용자 1000명, 환율 1500, USD, blended, 사용자군 60/20/15/5, 모델 믹스 high 20%/mid 80%가 시작값이다.
18. 데이터 수정 후 node scripts/parse-data.js를 실행해 dynamicData.json을 갱신한다.
19. 최종 검증으로 npm run lint와 npm run build를 실행한다.
20. 사용자가 반영 또는 배포라고 명시하기 전에는 git push나 ZIP 패키징을 하지 않는다.
```
